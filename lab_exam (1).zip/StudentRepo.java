class Student {
	     {
	        System.out.println("Hello, World!"); 
	    }
	}

  public class StudentRepo { 
  public void createDBAndTable() { id } 
  public void insertIntoTable(Student student) { id } 
} 