
public class launcher {

	public static void main(String[] args) {
		

	}

}
